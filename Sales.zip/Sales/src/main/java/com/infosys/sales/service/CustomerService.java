package com.infosys.sales.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.aspectj.weaver.ast.HasAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.sales.entity.CustomerEntity;
import com.infosys.sales.model.Customer;
import com.infosys.sales.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository repository;
	
	public List<Customer> getAll() {
		List<Customer> customerList = new ArrayList<>();
		
		for (CustomerEntity entity : repository.findAll()) {
			Customer customer = new Customer();
			customer.setId(entity.getId());
			customer.setFirstName(entity.getFirstName());
			customer.setLastName(entity.getLastName());			
			customerList.add(customer);
		}
		return customerList;
	}
	
	/*
	 * public Map<String, ?> get() { Map<String, Customer> map = new HashMap<>();
	 * 
	 * for (CustomerEntity entity : repository.findAll()) { Customer customer = new
	 * Customer(); customer.setId(entity.getId());
	 * customer.setFirstName(entity.getFirstName());
	 * customer.setLastName(entity.getLastName()); map.put(customer.getFirstName(),
	 * customer); } return map; }
	 */
	
	public Customer findBy(Long id) {
		Optional<CustomerEntity> optional = repository.findById(id);
		
		CustomerEntity entity = optional.get();
		Customer customer = new Customer();
	
		customer.setFirstName(entity.getFirstName());
		customer.setLastName(entity.getLastName());			
		
		return customer;
	}
	
	public String update(Customer customer) {
		Optional<CustomerEntity> optional = repository.findById(customer.getId());
		
		CustomerEntity entity = optional.get();
		entity.setFirstName(customer.getFirstName());
		entity.setLastName(customer.getLastName());
		
		repository.save(entity);
		return "SUCCESS";
	}
	
	public Customer save(Customer customer) {
		CustomerEntity entity = new CustomerEntity();
		entity.setFirstName(customer.getFirstName());
		entity.setLastName(customer.getLastName());
		
		CustomerEntity returnEntity = repository.save(entity);
		customer.setId(returnEntity.getId());
		return customer;
	}
	
	public void delete(Long id) {
		repository.deleteById(id);
	}
	
}

