package com.infosys.sales.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.sales.model.Order;
import com.infosys.sales.service.OrdersService;

@RestController
@RequestMapping(value = "/orders")
public class OrderController {
	
	@Autowired
	private OrdersService service;

	@GetMapping
	public List<Order> getAll() {
		return service.getAll();
	}

	@PostMapping
	public void save(@RequestBody Order order) {
		service.save(order);
	}

	@PutMapping
	String update(@RequestBody Order order) {
		return service.update(order);
	}

	@DeleteMapping("/{id}")
	void delete(@PathVariable Long id) {
		service.delete(id);
	}

}