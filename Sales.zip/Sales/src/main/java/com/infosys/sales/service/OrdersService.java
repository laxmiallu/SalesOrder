package com.infosys.sales.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.sales.entity.OrderEntity;
import com.infosys.sales.model.Order;
import com.infosys.sales.repository.OrderRepository;

@Service
public class OrdersService {

	@Autowired
	private OrderRepository orderRepo;

	public List<Order> getAll() {
		List<Order> orderList = new ArrayList<>();

		for (OrderEntity e : orderRepo.findAll()) {
			Order order = new Order();
			order.setId(e.getId());
			order.setCid(e.getCid());
			order.setDiscount(e.getDiscount());
			order.setTotalAmount(e.getTotalAmount());
			order.setTransactionDate((java.util.Date)e.getTransactionDate());
			
			orderList.add(order);
		}
	 
		return orderList;
	}
	public Order findBy(Long id) {
		Optional<OrderEntity> optional = orderRepo.findById(id);
		
		OrderEntity entity = optional.get();
		Order order = new Order();
		
		order.setId(entity.getId());
		order.setCid(entity.getCid());
		order.setTotalAmount(entity.getTotalAmount());
		 order.setTransactionDate(entity.getTransactionDate());
		order.setDiscount(entity.getDiscount());
		return order;
	
		 
	}
	
	public String update(Order order ) {
		Optional<OrderEntity> optional =orderRepo.findById( order.getId( ));
		
		OrderEntity entity = optional.get();
		entity.setCid(order.getCid());
		entity.setDiscount(order.getDiscount());
		entity.setTotalAmount(order.getTotalAmount());
		 entity.setTransactionDate((java.sql.Date)order.getTransactionDate());
		
		orderRepo.save(entity);
		return "SUCCESS";
	}
	
	public Order save(Order order) {
		OrderEntity entity = new OrderEntity();
		entity.setCid(order.getCid());
		entity.setDiscount(order.getDiscount());
		
		entity.setTotalAmount(order.getTotalAmount());
		java.util.Date d = new java.util.Date();
		 d=order.getTransactionDate();
		
		entity.setTransactionDate((java.sql.Date)(d));
		OrderEntity returnEntity = orderRepo.save(entity);
		order.setId(returnEntity.getId());
		return order;
	}
	
	public void delete(Long id) {
		orderRepo.deleteById(id);
	}
	
}
