package com.infosys.sales.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.infosys.sales.entity.CustomerEntity;
import com.infosys.sales.entity.ProductEntity;
import com.infosys.sales.model.Customer;
import com.infosys.sales.model.Product;
import com.infosys.sales.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepo;
	
	public List<Product> getAll() {
		List<Product> prodList = new ArrayList<>();
		for (ProductEntity entity : productRepo.findAll()) {
			Product product = new Product();
			product.setId(entity.getId());
			product.setName(entity.getName());
			product.setDescription(entity.getDescription());
			product.setPrice(entity.getPrice());
			
			product.setSeller(entity.getSeller());
			product.setQty(entity.getQty());
			product.setOid(entity.getOid());
			
			prodList.add(product);
			
		}
		
		return prodList;
		
	}
	public  Product  get(Long id){
	   Optional<ProductEntity> optional= productRepo.findById(id);
	   ProductEntity pe =optional.get();
	   Product p = new Product();
	   p.setDescription(pe.getDescription());
	   p.setName(pe.getName());
	   p.setOid(pe.getOid());
	   p.setPrice(pe.getPrice());
	   p.setSeller(pe.getSeller());
	   p.setQty(pe.getQty());
 		 
 	
		 
		return p;
		
	}
	public Product save(Product p ) {
		ProductEntity entity = new ProductEntity();
		entity.setDescription(p.getDescription());
		entity.setId(p.getId());
		entity.setName(p.getName());
		entity.setOid(p.getOid());
		entity.setPrice(p.getPrice());
		entity.setSeller(p.getSeller());
		entity.setQty(p.getQty());
		 
		ProductEntity returnEntity = productRepo.save(entity);
		p.setId(returnEntity.getId());
		return p;
	}
	
}

