package com.infosys.sales.model;

import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
public class Shipping {
	
	
	private Long  id;
	private Long oid;
	private Long cid;
	private Date shippingDate;
	
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getOid() {
			return oid;
		}
		public void setOid(Long oid) {
			this.oid = oid;
		}
		public Long getCid() {
			return cid;
		}
		public void setCid(Long cid) {
			this.cid = cid;
		}
		public Date getShippingDate() {
			return shippingDate;
		}
		public void setShippingDate(Date shippingDate) {
			this.shippingDate = shippingDate;
		}
		@Override
		public String toString() {
			return "Shipping [id=" + id + ", oid=" + oid + ", cid=" + cid + ", shippingDate=" + shippingDate + "]";
		}
		
			
			
		
	}