package com.infosys.sales.model;

import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
public class Order {

	private Long id;
	private Long cid;
	private Long totalAmount;
	private Date transactionDate;
	private Long discount;
	
	public Long getId() {
		return id;
	}
	
	public void setDiscount(Long discount) {
		this.discount = discount;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getCid() {
		return cid;
	}
	
	public void setCid(Long cid) {
		this.cid = cid;
	}
	
	public Long getTotalAmount() {
		return totalAmount;
	}
	
	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Long getDiscount() {
		return discount;
	}
	
	@Override
	public String toString() {
		return "Order [id=" + id + ", cid=" + cid + ", totalAmount=" + totalAmount + ", transactionDate="
				+ transactionDate + ", discount=" + discount + "]";
	}	
	
}