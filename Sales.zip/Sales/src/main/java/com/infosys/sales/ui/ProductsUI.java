package com.infosys.sales.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.sales.model.Product;
import com.infosys.sales.service.ProductService;

@RestController

@RequestMapping(value = "/products/ui")
public class ProductsUI {

	@Autowired
	private ProductService service;

	@GetMapping
	public ModelAndView getAll() {
		ModelAndView mv = new ModelAndView();

		mv.addObject("products", service.getAll());
		mv.setViewName("products");
		return mv;
	}

	@PostMapping
	public ModelAndView save(@RequestBody Product product) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("products", service.save(product));
		mv.setViewName("productAdd");
		return mv;
	}

}
