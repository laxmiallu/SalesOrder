package com.infosys.sales.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.infosys.sales.entity.CustomerEntity;
import com.infosys.sales.entity.ShippingEntity;
import com.infosys.sales.model.Customer;
import com.infosys.sales.model.Shipping;
import com.infosys.sales.repository.ShippingRepository;

public class ShippingService {
	@Autowired
	ShippingRepository shipRepo;
	
	
	
	public List<Shipping> getAll(){
		
		List<Shipping> shipList = new ArrayList<>();
		for (ShippingEntity se :shipRepo.findAll())
		{
			Shipping s = new Shipping();
			s.setId(se.getId());
			s.setCid(se.getCid());
			s.setOid(se.getOid());
			s.setShippingDate((java.util.Date)se.getShippingDate());
			shipList.add(s);
			
		}
		return shipList;
	}
	
	public void save(Shipping s) {
		
		ShippingEntity se = new ShippingEntity();
		se.setCid(s.getCid());
		se.setShippingDate((Date)s.getShippingDate());
		se.setId(s.getId());
		se.setOid(s.getOid());
		 
		shipRepo.save(se);
	}
	public String update(Shipping shipping) {
		Optional<ShippingEntity> optional =shipRepo.findById(shipping.getId());
		
		ShippingEntity entity = optional.get();
		entity.setCid(shipping.getCid());
		entity.setId(shipping.getId());
		entity.setOid(shipping.getOid());
		entity.setShippingDate((java.sql.Date)shipping.getShippingDate());
		shipRepo.save(entity);
		return "SUCCESS";
	}

}
