package com.infosys.sales.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.sales.model.Customer;
import com.infosys.sales.service.CustomerService;

@RestController

@RequestMapping(value = "/customers/ui")
public class CustomerUI {

	@Autowired
	private CustomerService service;

	@GetMapping
	public ModelAndView getAll() {
		ModelAndView mv = new ModelAndView();

		mv.addObject("customers", service.getAll());
		mv.setViewName("customers");
		return mv;
	}

	@PostMapping
	public ModelAndView save(@RequestBody Customer customer) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("customer", service.save(customer));
		mv.setViewName("customerAdd");
		return mv;
	}

}
