package com.infosys.sales.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.sales.entity.ShippingEntity;
import com.infosys.sales.model.Shipping;
import com.infosys.sales.service.ShippingService;

@RestController
@RequestMapping(value="/shipping")
public class ShippingController {
	
	ShippingService shipService;
	
	@GetMapping
	public List<Shipping> getAll()
	{
		return shipService.getAll();
	}
	 
	
	
}
