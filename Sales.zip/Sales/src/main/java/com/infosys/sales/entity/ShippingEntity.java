package com.infosys.sales.entity;
import java.sql.Date;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SHIPPING")
public class ShippingEntity {

	@Id
	@GeneratedValue
	@Column(name="ID")
	private Long  id;
	
	@Column(name="OID")
	private Long oid;
	
	@Column(name="CID")
	private Long cid;
	
	@Column(name="SHIPPING_DATE")
	private Date shippingDate;
	
			public Long getId() {
				return id;
			}
			public void setId(Long id) {
				this.id = id;
			}
			public Long getOid() {
				return oid;
			}
			public void setOid(Long oid) {
				this.oid = oid;
			}
			public Long getCid() {
				return cid;
			}
			public void setCid(Long cid) {
				this.cid = cid;
			}
			public Date getShippingDate() {
				return shippingDate;
			}
			public void setShippingDate(Date shippingDate) {
				this.shippingDate = shippingDate;
			}
			@Override
			public String toString() {
				return "ShippingEntity [id=" + id + ", oid=" + oid + ", cid=" + cid + ", shippingDate=" + shippingDate + "]";
			}
			
			
	
}
