package com.infosys.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.sales.entity.ShippingEntity;

public interface ShippingRepository extends JpaRepository<ShippingEntity,Long> {

}
