package com.infosys.sales.entity;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ORDERS")
public class OrderEntity {
	
	@Id
	@Column(name="ID")
	private Long id;
	
	  
	@Column(name="CID")
	private Long cid;
	
	@Column(name="TOTAL_AMOUNT")
	private Long  totalAmount;

	@Column(name="TRANSACTION_DATE")
	private Date transactionDate;
	
	@Column(name="DISCOUNT")
	private Long discount;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getCid() {
		return cid;
	}
	
	public void setCid(Long cid) {
		this.cid = cid;
	}
	
	public Long getTotalAmount() {
		return totalAmount;
	}
	
	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Long getDiscount() {
		return discount;
	}
	
	public void setDiscount(Long discount) {
		this.discount = discount;
	}
	
	@Override
	public String toString() {
		return "OrderEntity [id=" + id + ", cid=" + cid + ", totalAmount=" + totalAmount + ", transactionDate="
				+ transactionDate + ", discount=" + discount + "]";
	}
	
	
}